﻿//添加适配文件。根据 huawei-adapter.js 放置的目录，require 路径相应调整  
require("src/huawei-adapter.js");
//导入游戏运行代码code.js
require("index.js");
