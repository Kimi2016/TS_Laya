declare module Zlib {
    /**
     * 解压
     */
    class Inflate {
        /**
         * @param data // compressed = Array.<number> or Uint8Array
         */
        constructor(data: any);
        decompress(): any;
    }

    /**
     * 压缩
     */
    class Deflate {
        /**
         * CompressionType：{NONE:0, FIXED:1, DYNAMIC:2, RESERVED:3}
         */
        static CompressionType:any; 
        /**
         * @param data  // plain = Array.<number> or Uint8Array
         */
        constructor(data: any);
        
        compress(): Uint8Array;
    }
}