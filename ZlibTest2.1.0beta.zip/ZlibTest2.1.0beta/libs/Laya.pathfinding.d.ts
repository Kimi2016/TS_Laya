declare module PathFinding {
    module core {
        class DiagonalMovement {
            static Always: number;
            static Never: number;
            static IfAtMostOneObstacle: number;
            static OnlyWhenNoObstacles: number;
        }
        class Grid {
            constructor(width_or_matrix: number | Array<Array<number>>, height?: number, matrix?: Array<Array<number>>);
            getNodeAt(x, y): Node;
            getNeighbors(node, diagonalMovement): Array<Node>;
            isWalkableAt(x, y): boolean;
            isInside(x, y): boolean;
            setWalkableAt(x, y, walkable);
            clone(): void;
            reset(): void;
        }
        class Node {
            x: number;
            y: number;
            walkable:boolean;
            /** matrix.value */
            matrixValue: number;
            constructor(x: number, y: number, walkable: boolean);
        }
        class Util {
            /**
             * Backtrace according to the parent records and return the path.
             * (including both start and end nodes)
             * @param {Node} node End node
             * @return {Array<Array<number>>} the path
             */
            //static backtrace(node: Node): any[][];
            /**
             * Backtrace from start and end node, and return the path.
             * (including both start and end nodes)
             * @param {Node}
             * @param {Node}
             */
            //static biBacktrace(nodeA: Node, nodeB: Node): any[][];
            /**
             * Compute the length of the path.
             * @param {Array<Array<number>>} path The path
             * @return {number} The length of the path
             */
            //static pathLength(path: any): number;
            /**
             * Given the start and end coordinates, return all the coordinates lying
             * on the line formed by these coordinates, based on Bresenham's algorithm.
             * http://en.wikipedia.org/wiki/Bresenham's_line_algorithm#Simplification
             * @param {number} x0 Start x coordinate
             * @param {number} y0 Start y coordinate
             * @param {number} x1 End x coordinate
             * @param {number} y1 End y coordinate
             * @return {Array<Array<number>>} The coordinates on the line
             */
            //static interpolate(x0,y0,x1,y1): any[][];
            /**
             * Given a compressed path, return a new path that has all the segments
             * in it interpolated.
             * @param {Array<Array<number>>} path The path
             * @return {Array<Array<number>>} expanded path
             */
            //static expandPath(path): any[];
            /**
             * Smoothen the give path.
             * The original path will not be modified; a new path will be returned.
             * @param {PF.Grid} grid
             * @param {Array<Array<number>>} path The path
             * @return {Array<Array<number>>} Smoothened path
             */
            static smoothenPath(grid, path): Array<Array<number>>;
            /**
             * Compress a path, remove redundant nodes without altering the shape
             * The original path is not modified
             * @param {Array<Array<number>>} path The path
             * @return {Array<Array<number>>} The compressed path
             */
            //static compressPath(path): Array<Array<number>>;
        }
    }
    module finders {
        class AStarFinder {
            /**
             * 
             * @param opt {
             *  allowDiagonal:boolean 允许对角,
             *  dontCrossCorners:boolean 不能交叉角,
             *  diagonalMovement:boolean 对角运动,
             *  heuristic:boolean 启发式算法(搜索),
             *  weight:number 权重
             *  }
             */
            constructor(opt);
            findPath(startX: number, startY: number, endX: number, endY: number, grid: PathFinding.core.Grid): Array<Array<number>>;
        }

        class BestFirstFinder extends AStarFinder {
            BestFirstFinder(opt);
        }
    }

}