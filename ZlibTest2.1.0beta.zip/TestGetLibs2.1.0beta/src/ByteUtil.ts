export default class ByteUtil {

    /**
     * 压缩 string
     * @param jsonFormat 
     * @returns Array.<number> or Uint8Array
     */
    public static compressString(jsonFormat: string): any {
        var byte = new Laya.Byte();
        byte.writeUTFBytes(jsonFormat);
        var compressed = this.compress(byte);
        return compressed;
    }

    /* 压缩 二进制数据
     * @param byte 
     * @returns Array.<number> or Uint8Array
     */
    public static compress(byte: Laya.Byte): Uint8Array {
        var byte8 = new Uint8Array(byte.buffer);
        var defate = new Zlib.Deflate(byte8);
        var compressed = defate.compress();
        return compressed;
    }

    /**
     * 解压 二进制数据
     * @param compressed  Array.<number> or Uint8Array
     */
    public static decompress(compressed: any): Laya.Byte {
        var inflate = new Zlib.Inflate(compressed);
        var plain = inflate.decompress();
        var plainByte: Laya.Byte = new Laya.Byte(plain);
        return plainByte;
    }


    /**
     * 解压文件数据
     * @param compressed 
     */
    public static unzip(compressed: Uint8Array): any {
        // compressed = Array.<number> or Uint8Array
        var unzip = new Zlib.Unzip(compressed);
        var filenames = unzip.getFilenames();
        console.log(filenames);
        var plain = unzip.decompress(filenames[0]);
        return plain
    }
}