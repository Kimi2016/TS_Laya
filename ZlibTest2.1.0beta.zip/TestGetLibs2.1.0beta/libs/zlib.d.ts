
//https://github.com/imaya/zlib.js

declare module Zlib {
    /**
     * 解压
     */
    class Inflate {
        /**
         * @param data // compressed = Array.<number> or Uint8Array
         */
        constructor(input: any);
        decompress(): Uint8Array;
    }

    /**
     * 压缩
     */
    class Deflate {
        /**
         * DefaultBufferSize：32768
         */
        //static DefaultBufferSize: number;
        /**
         * CompressionType：{NONE:0, FIXED:1, DYNAMIC:2, RESERVED:3}
         */
        //static CompressionType:any; 
        /**
         * @param data  // plain = Array.<number> or Uint8Array
         * @param opt_params // ZLIB Option = 
         * {
         *     compressionType: Zlib.Deflate.CompressionType, // compression type
         *     lazy: number // lazy matching parameter
         * }
         */
        constructor(input: any, opt_params?: any);
        compress(): Uint8Array;
    }

    /**
     * 压缩文件
     */
    class Zip {
        constructor(opt_params?: any);
        addFile(input, opt_params);
        compress();
        setPassword();
    }

    /**
     * 解压文件
     */
    class Unzip {
        /**
         * 
         * @param input compressed = Array.<number> or Uint8Array
         * @param opt_params 
         */
        constructor(input: any, opt_params?: any);
        decompress(filename);
        getFilenames();
        setPassword();
    }

    class Util {
        static stringToByteArray(str)
    }
}