import VertexMesh = Laya.VertexMesh;
import Shader3D = Laya.Shader3D;
export default class UnlitGrayMaterial extends Laya.UnlitMaterial {
    static readonly NAME = "UnlitGrayMaterial";

    static __Init__() {
        var attributeMap: any = {
            'a_Position': VertexMesh.MESH_POSITION0,
            'a_Color': VertexMesh.MESH_COLOR0,
            'a_Texcoord0': VertexMesh.MESH_TEXTURECOORDINATE0,
            'a_BoneWeights': VertexMesh.MESH_BLENDWEIGHT0,
            'a_BoneIndices': VertexMesh.MESH_BLENDINDICES0,
            'a_MvpMatrix': VertexMesh.MESH_MVPMATRIX_ROW0
        };
        var uniformMap: any = {
            'u_Bones': Shader3D.PERIOD_CUSTOM,
            'u_AlbedoTexture': Shader3D.PERIOD_MATERIAL,
            'u_AlbedoColor': Shader3D.PERIOD_MATERIAL,
            'u_TilingOffset': Shader3D.PERIOD_MATERIAL,
            'u_AlphaTestValue': Shader3D.PERIOD_MATERIAL,
            'u_MvpMatrix': Shader3D.PERIOD_SPRITE,
            'u_FogStart': Shader3D.PERIOD_SCENE,
            'u_FogRange': Shader3D.PERIOD_SCENE,
            'u_FogColor': Shader3D.PERIOD_SCENE
        };
        var stateMap: any = {
            's_Cull': Shader3D.RENDER_STATE_CULL,
            's_Blend': Shader3D.RENDER_STATE_BLEND,
            's_BlendSrc': Shader3D.RENDER_STATE_BLEND_SRC,
            's_BlendDst': Shader3D.RENDER_STATE_BLEND_DST,
            's_DepthTest': Shader3D.RENDER_STATE_DEPTH_TEST,
            's_DepthWrite': Shader3D.RENDER_STATE_DEPTH_WRITE
        }
        //var UnlitVS = "#include \"Lighting.glsl\";\r\n\r\nattribute vec4 a_Position;\r\n\r\nattribute vec2 a_Texcoord0;\r\n\r\n#ifdef GPU_INSTANCE\r\n\tattribute mat4 a_MvpMatrix;\r\n#else\r\n\tuniform mat4 u_MvpMatrix;\r\n#endif\r\n\r\nattribute vec4 a_Color;\r\nvarying vec4 v_Color;\r\nvarying vec2 v_Texcoord0;\r\n\r\n#ifdef TILINGOFFSET\r\n\tuniform vec4 u_TilingOffset;\r\n#endif\r\n\r\n#ifdef BONE\r\n\tconst int c_MaxBoneCount = 24;\r\n\tattribute vec4 a_BoneIndices;\r\n\tattribute vec4 a_BoneWeights;\r\n\tuniform mat4 u_Bones[c_MaxBoneCount];\r\n#endif\r\n\r\nvoid main() {\r\n\tvec4 position;\r\n\t#ifdef BONE\r\n\t\tmat4 skinTransform = u_Bones[int(a_BoneIndices.x)] * a_BoneWeights.x;\r\n\t\tskinTransform += u_Bones[int(a_BoneIndices.y)] * a_BoneWeights.y;\r\n\t\tskinTransform += u_Bones[int(a_BoneIndices.z)] * a_BoneWeights.z;\r\n\t\tskinTransform += u_Bones[int(a_BoneIndices.w)] * a_BoneWeights.w;\r\n\t\tposition=skinTransform*a_Position;\r\n\t#else\r\n\t\tposition=a_Position;\r\n\t#endif\r\n\t#ifdef GPU_INSTANCE\r\n\t\tgl_Position = a_MvpMatrix * position;\r\n\t#else\r\n\t\tgl_Position = u_MvpMatrix * position;\r\n\t#endif\r\n\r\n\t#ifdef TILINGOFFSET\r\n\t\tv_Texcoord0=TransformUV(a_Texcoord0,u_TilingOffset);\r\n\t#else\r\n\t\tv_Texcoord0=a_Texcoord0;\r\n\t#endif\r\n\r\n\t#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\r\n\t\tv_Color = a_Color;\r\n\t#endif\r\n\tgl_Position=remapGLPositionZ(gl_Position);\r\n}";
        //var UnlitPS = "#ifdef GL_FRAGMENT_PRECISION_HIGH\r\n\tprecision highp float;\r\n#else\r\n\tprecision mediump float;\r\n#endif\r\n\r\n#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\r\n\tvarying vec4 v_Color;\r\n#endif\r\n\r\n#ifdef ALBEDOTEXTURE\r\n\tuniform sampler2D u_AlbedoTexture;\r\n\tvarying vec2 v_Texcoord0;\r\n#endif\r\n\r\nuniform vec4 u_AlbedoColor;\r\n\r\n#ifdef ALPHATEST\r\n\tuniform float u_AlphaTestValue;\r\n#endif\r\n\r\n#ifdef FOG\r\n\tuniform float u_FogStart;\r\n\tuniform float u_FogRange;\r\n\t#ifdef ADDTIVEFOG\r\n\t#else\r\n\t\tuniform vec3 u_FogColor;\r\n\t#endif\r\n#endif\r\n\r\nvoid main()\r\n{\r\n\tvec4 color =  u_AlbedoColor;\r\n\t#ifdef ALBEDOTEXTURE\r\n\t\tcolor *= texture2D(u_AlbedoTexture, v_Texcoord0);\r\n\t#endif\r\n\t#if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)\r\n\t\tcolor *= v_Color;\r\n\t#endif\r\n\t\r\n\t#ifdef ALPHATEST\r\n\t\tif(color.a < u_AlphaTestValue)\r\n\t\t\tdiscard;\r\n\t#endif\r\n\t\r\n\tgl_FragColor = color;\r\n\t\r\n\t#ifdef FOG\r\n\t\tfloat lerpFact = clamp((1.0 / gl_FragCoord.w - u_FogStart) / u_FogRange, 0.0, 1.0);\r\n\t\t#ifdef ADDTIVEFOG\r\n\t\t\tgl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.0), lerpFact);\r\n\t\t#else\r\n\t\t\tgl_FragColor.rgb = mix(gl_FragColor.rgb, u_FogColor, lerpFact);\r\n\t\t#endif\r\n\t#endif\r\n\t\r\n}\r\n\r\n";

        var UnlitVS = `#include "Lighting.glsl";
        attribute vec4 a_Position;
        attribute vec2 a_Texcoord0;
        #ifdef GPU_INSTANCE
            attribute mat4 a_MvpMatrix;
        #else
            uniform mat4 u_MvpMatrix;
        #endif
        
        attribute vec4 a_Color;
        varying vec4 v_Color;
        varying vec2 v_Texcoord0;
        
        #ifdef TILINGOFFSET
            uniform vec4 u_TilingOffset;
        #endif
        
        #ifdef BONE
            const int c_MaxBoneCount = 24;
            attribute vec4 a_BoneIndices;
            attribute vec4 a_BoneWeights;
            uniform mat4 u_Bones[c_MaxBoneCount];
        #endif
        
        void main() {
            vec4 position;
            #ifdef BONE
                mat4 skinTransform = u_Bones[int(a_BoneIndices.x)] * a_BoneWeights.x;
                skinTransform += u_Bones[int(a_BoneIndices.y)] * a_BoneWeights.y;
                skinTransform += u_Bones[int(a_BoneIndices.z)] * a_BoneWeights.z;
                skinTransform += u_Bones[int(a_BoneIndices.w)] * a_BoneWeights.w;
                position=skinTransform*a_Position;
            #else
                position=a_Position;
            #endif
            #ifdef GPU_INSTANCE
                gl_Position = a_MvpMatrix * position;
            #else
                gl_Position = u_MvpMatrix * position;
            #endif
        
            #ifdef TILINGOFFSET
                v_Texcoord0=TransformUV(a_Texcoord0,u_TilingOffset);
            #else
                v_Texcoord0=a_Texcoord0;
            #endif
        
            #if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)
                v_Color = a_Color;
            #endif
            gl_Position=remapGLPositionZ(gl_Position);
        }`;

        var UnlitFS = `#ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
        #else
            precision mediump float;
        #endif
        
        #if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)
            varying vec4 v_Color;
        #endif
        
        #ifdef ALBEDOTEXTURE
            uniform sampler2D u_AlbedoTexture;
            varying vec2 v_Texcoord0;
        #endif
        
        uniform vec4 u_AlbedoColor;
        
        #ifdef ALPHATEST
            uniform float u_AlphaTestValue;
        #endif
        
        lowp float gray;
        
        void main()
        {
            vec4 color = u_AlbedoColor;
            #ifdef ALBEDOTEXTURE
                color *= texture2D(u_AlbedoTexture, v_Texcoord0);
            #endif
            #if defined(COLOR)&&defined(ENABLEVERTEXCOLOR)
                color *= v_Color;
            #endif
            
            #ifdef ALPHATEST
                if(color.a < u_AlphaTestValue)
                    discard;
            #endif
            
            gray = dot(color.xyz, vec3(0.299, 0.587, 0.114));
            gl_FragColor = vec4(gray, gray, gray, color.w);
        }`;

        //注册CustomShader 
        var shader = Shader3D.add(UnlitGrayMaterial.NAME, null, null, true);
        //创建一个SubShader
        var subShader = new Laya.SubShader(attributeMap, uniformMap);
        //往自定义shader 添加 subShader
        shader.addSubShader(subShader);
        //往新创建的subShader 添加 shaderPass
        var pass = subShader.addShaderPass(UnlitVS, UnlitFS, stateMap);
        //pass.renderState.cull = Laya.RenderState.CULL_NONE;
    }

    constructor() {
        super();
        //设置使用Shader名字。
        this.setShaderName(UnlitGrayMaterial.NAME);
        this.renderMode = Laya.UnlitMaterial.RENDERMODE_CUTOUT;
    }

	/**
	 * 克隆。
	 * @return	 克隆副本。
	 * @override
	 */
    clone(): any {
        var dest: UnlitGrayMaterial = new UnlitGrayMaterial();
        this.cloneTo(dest);
        return dest;
    }
}