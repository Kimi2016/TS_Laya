//import Shader_Box_VS = from "./Shader_Box.vs";
//import Shader_Box_FS = from "./Shader_Box.fs";
import Shader3D = Laya.Shader3D;
import VertexMesh = Laya.VertexMesh;

export default class Shader_Box extends Laya.BaseMaterial {
    static NAME = "Shader_Box";

    static __Init__() {
        //Shader_Box
        var attributeMap = {
            'a_Position': VertexMesh.MESH_POSITION0,
            'a_Normal': VertexMesh.MESH_NORMAL0
        }
        var uniformMap = {
            'u_MvpMatrix': Shader3D.PERIOD_SPRITE,
            'u_WorldMat': Shader3D.PERIOD_SPRITE
        }
        var vs = `
        #include "Lighting.glsl";
        attribute vec4 a_Position;
        attribute vec3 a_Normal;
        uniform mat4 u_MvpMatrix;
        uniform mat4 u_WorldMat;

        varying vec3 v_Normal;
        void main()
        {
            gl_Position = u_MvpMatrix * a_Position;
            mat3 worldMat = mat3(u_WorldMat);
            v_Normal = worldMat * a_Normal;
            gl_Position = remapGLPositionZ(gl_Position);
        }`;

        var fs = `
        #ifdef FSHIGHPRECISION
        precision highp float;
        #else
        precision mediump float;
        #endif
        
        varying vec3 v_Normal;
        
        void main()
        {
            lowp float gray;
            gray = dot(v_Normal.xyz, vec3(0.299, 0.587, 0.114));
            gl_FragColor=vec4(gray, gray, gray, 1.0);
            //gl_FragColor=vec4(v_Normal,1.0);
        }`;



        //注册CustomShader 
        var shader = Shader3D.add(Shader_Box.NAME, null, null, true);
        //创建一个SubShader
        var subShader = new Laya.SubShader(attributeMap, uniformMap);
        //往自定义shader 添加 subShader
        shader.addSubShader(subShader);
        //往新创建的subShader 添加 shaderPass
        subShader.addShaderPass(vs, fs);
    }

    constructor() {
        super();
        this.setShaderName(Shader_Box.NAME);
    }

}