#ifdef FSHIGHPRECISION
precision highp float;
#else
precision mediump float;
#endif

varying vec3 v_Normal;

void main()
{
    gl_FragColor = vec4(v_normal,1.0);
}