#ifdef GL_FRAGMENT_PRECISION_HIGH
  precision highp float;
#else
	precision mediump float;
#endif

varying vec3 v_Normal;
varying vec3 v_ViewDir;

uniform vec4 u_RimColor;
uniform vec4 u_InnerColor;
uniform float u_RimPower;
uniform float u_InnerColorPower;
uniform float u_AlphaPower;
uniform float u_AllPower;

void main()
{
	lowp vec4 color;
	lowp vec3 viewDir;
	viewDir = normalize(v_ViewDir);

	highp float rim;
	rim = 1.0 - clamp(dot(normalize(viewDir), v_Normal), 0.0, 1.0);
  
	highp float rim_Power;
	rim_Power = pow (rim, u_RimPower);

	highp vec3 emission;
	emission = ((u_RimColor.xyz * rim_Power * u_AllPower) + (u_InnerColor.xyz * u_InnerColorPower));
	
	highp float alpha_Power;
	alpha_Power = pow(rim, u_AlphaPower) * u_AllPower;
	
	lowp float alpha;
	alpha = alpha_Power;

	color.xyz = emission;
	color.w = alpha;
	gl_FragColor = color;

	//测试
	//gl_FragColor = u_RimColor;
    //gl_FragColor = u_InnerColor;
}