//import TransparentRim_VS = from "./TransparentRim.vs";
//import TransparentRim_FS = from "./TransparentRim.fs";
import Shader3D = Laya.Shader3D;
import VertexMesh = Laya.VertexMesh;

/**
 * @author Kimi
 * 透明发光
 */
export default class TransparentRimMaterial extends Laya.UnlitMaterial {

    static NAME = "TransparentRimMaterial";

    static u_RimColor: number = Shader3D.propertyNameToID("u_RimColor");
    static u_InnerColor: number = Shader3D.propertyNameToID("u_InnerColor");
    static u_InnerColorPower: number = Shader3D.propertyNameToID("u_InnerColorPower");
    static u_RimPower: number = Shader3D.propertyNameToID("u_RimPower");
    static u_AlphaPower: number = Shader3D.propertyNameToID("u_AlphaPower");
    static u_AllPower: number = Shader3D.propertyNameToID("u_AllPower");

    static __Init__() {
        var attributeMap = {
            'a_Position': VertexMesh.MESH_POSITION0,
            'a_Normal': VertexMesh.MESH_NORMAL0,

            //Bone
            'a_Texcoord0': VertexMesh.MESH_TEXTURECOORDINATE0,
            'a_BoneWeights': VertexMesh.MESH_BLENDWEIGHT0,
            'a_BoneIndices': VertexMesh.MESH_BLENDINDICES0,
            'a_MvpMatrix': VertexMesh.MESH_MVPMATRIX_ROW0,
            'a_WorldMat': VertexMesh.MESH_WORLDMATRIX_ROW0
        }
        var uniformMap = {
            //Bone
            'u_Bones': Shader3D.PERIOD_CUSTOM,
            'u_MvpMatrix': Shader3D.PERIOD_SPRITE,
            'u_WorldMat': Shader3D.PERIOD_SPRITE,

            'u_CameraPos': Shader3D.PERIOD_CAMERA,
            'u_View': Shader3D.PERIOD_CAMERA,

            //---------//
            'u_RimColor': Shader3D.PERIOD_MATERIAL,
            'u_InnerColor': Shader3D.PERIOD_MATERIAL,
            'u_InnerColorPower': Shader3D.PERIOD_MATERIAL,
            'u_RimPower': Shader3D.PERIOD_MATERIAL,
            'u_AlphaPower': Shader3D.PERIOD_MATERIAL,
            'u_AllPower': Shader3D.PERIOD_MATERIAL,
        }
        var stateMap: any = {
            's_Cull': Shader3D.RENDER_STATE_CULL,
            's_Blend': Shader3D.RENDER_STATE_BLEND,
            's_BlendSrc': Shader3D.RENDER_STATE_BLEND_SRC,
            's_BlendDst': Shader3D.RENDER_STATE_BLEND_DST,
            's_DepthTest': Shader3D.RENDER_STATE_DEPTH_TEST,
            's_DepthWrite': Shader3D.RENDER_STATE_DEPTH_WRITE
        }
        var vs = `
        #include "Lighting.glsl";
        attribute vec4 a_Position;
        attribute vec3 a_Normal;
        attribute vec2 a_Texcoord0;

        #ifdef GPU_INSTANCE
            attribute mat4 a_MvpMatrix;
        #else
            uniform mat4 u_MvpMatrix;
        #endif

        #ifdef BONE
            const int c_MaxBoneCount = 24;
            attribute vec4 a_BoneIndices;
            attribute vec4 a_BoneWeights;
            uniform mat4 u_Bones[c_MaxBoneCount];
        #endif

        #ifdef GPU_INSTANCE
            attribute mat4 a_WorldMat;
        #else
            uniform mat4 u_WorldMat;
        #endif
        uniform vec3 u_CameraPos;

        varying vec3 v_Normal;
        varying vec2 v_Texcoord0;
        varying vec3 v_ViewDir;
        varying vec3 v_PositionWorld;

        void main()
        {
            vec4 position;
            #ifdef BONE
                mat4 skinTransform = u_Bones[int(a_BoneIndices.x)] * a_BoneWeights.x;
                skinTransform += u_Bones[int(a_BoneIndices.y)] * a_BoneWeights.y;
                skinTransform += u_Bones[int(a_BoneIndices.z)] * a_BoneWeights.z;
                skinTransform += u_Bones[int(a_BoneIndices.w)] * a_BoneWeights.w;
                position=skinTransform*a_Position;
            #else
                position=a_Position;
            #endif

            #ifdef GPU_INSTANCE
                gl_Position = a_MvpMatrix * position;
            #else
                gl_Position = u_MvpMatrix * position;
            #endif
            
            //#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)||defined(RECEIVESHADOW)
                mat4 worldMat;
                #ifdef GPU_INSTANCE
                    worldMat = a_WorldMat;
                #else
                    worldMat = u_WorldMat;
                #endif
            //#endif

            //#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)
            //	mat3 worldInvMat;
            //	#ifdef BONE
            //		worldInvMat=inverse(mat3(worldMat*skinTransform));
            //	#else
            //		worldInvMat=inverse(mat3(worldMat));
            //	#endif  
            //	v_Normal=a_Normal*worldInvMat;
            //#else
                v_Normal = mat3(worldMat) * a_Normal;
            //#endif
            
            //#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)||defined(RECEIVESHADOW)
                v_PositionWorld=(worldMat*position).xyz;
            //#endif
            
            //#if defined(DIRECTIONLIGHT)||defined(POINTLIGHT)||defined(SPOTLIGHT)
                v_ViewDir=u_CameraPos-v_PositionWorld;
            //#endif
            
            gl_Position = remapGLPositionZ(gl_Position);
        }`;

        var fs = `
        #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
        #else
            precision mediump float;
        #endif

        varying vec3 v_Normal;
        varying vec3 v_ViewDir;

        uniform vec4 u_RimColor;
        uniform vec4 u_InnerColor;
        uniform float u_RimPower;
        uniform float u_InnerColorPower;
        uniform float u_AlphaPower;
        uniform float u_AllPower;

        void main()
        {
            lowp vec4 color;
            lowp vec3 viewDir;
            viewDir = normalize(v_ViewDir);

            highp float rim;
            rim = 1.0 - clamp(dot(normalize(viewDir), v_Normal), 0.0, 1.0);
        
            highp float rim_Power;
            rim_Power = pow (rim, u_RimPower);

            highp vec3 emission;
            emission = ((u_RimColor.xyz * rim_Power * u_AllPower) + (u_InnerColor.xyz * u_InnerColorPower));
            
            highp float alpha_Power;
            alpha_Power = pow(rim, u_AlphaPower) * u_AllPower;
            
            lowp float alpha;
            alpha = alpha_Power;

            color.xyz = emission;
            color.w = alpha;
            gl_FragColor = color;

            //测试
            //gl_FragColor = u_RimColor;
            //gl_FragColor = u_InnerColor;
        }`;


        //注册CustomShader 
        var shader = Shader3D.add(TransparentRimMaterial.NAME, null, null, true);
        //创建一个SubShader
        var subShader = new Laya.SubShader(attributeMap, uniformMap, );
        //往自定义shader 添加 subShader
        shader.addSubShader(subShader);
        //往新创建的subShader 添加 shaderPass
        subShader.addShaderPass(vs, fs, stateMap);
    }

    private _RimColor: Laya.Vector4 = new Laya.Vector4(0.5, 0.5, 0.5, 0.5);
    private _InnerColor: Laya.Vector4 = new Laya.Vector4(0.5, 0.5, 0.5, 0.5);

    constructor() {
        super();
        this.setShaderName(TransparentRimMaterial.NAME);
        this.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;

        this.SetRimColor(128, 128, 128, 128);
        this.SetInnerColor(128, 128, 128, 128);
        //this.SetInnerColor(255, 89, 89, 128);

        this.u_RimPower = 2.5;
        this.u_InnerColorPower = 1;
        this.u_AlphaPower = 4;
        this.u_AllPower = 1;
    }

    /**
     * 设置边缘发光颜色
     * @param r 0-255
     * @param g 0-255
     * @param b 0-255
     * @param a 0-255
     */
    public SetRimColor(r: number, g: number, b: number, a: number) {
        this._RimColor.setValue(r / 255, g / 255, b / 255, a / 255);
        this.u_RimColor = this._RimColor;
    }

    /**
     *  边缘发光颜色
     */
    private set u_RimColor(value: Laya.Vector4) {
        if (value) {
            this._shaderValues.setVector(TransparentRimMaterial.u_RimColor, value)
        }
    }

    /**
     * 边缘发光强度 0-5:2.5
     */
    set u_RimPower(value: number) {
        if (value) {
            value = Math.max(0, Math.min(5, value))
            this._shaderValues.setNumber(TransparentRimMaterial.u_RimPower, value)
        }
    }

    /**
     * 设置内部颜色
     * @param r 0-255
     * @param g 0-255
     * @param b 0-255
     * @param a 0-255
     */
    public SetInnerColor(r: number, g: number, b: number, a: number) {
        this._InnerColor.setValue(r / 255, g / 255, b / 255, a / 255);
        this.u_InnerColor = this._InnerColor;
    }

    /**
     * 内部颜色
     */
    private set u_InnerColor(value: Laya.Vector4) {
        if (value) {
            this._shaderValues.setVector(TransparentRimMaterial.u_InnerColor, value)
        }
    }

    /**
     * 内部颜色强度 0-2:1
     */
    set u_InnerColorPower(value) {
        if (value) {
            value = Math.max(0, Math.min(2, value));
            this._shaderValues.setNumber(TransparentRimMaterial.u_InnerColorPower, value)
        }
    }

    /**
     * 透明度 0-8:4
     */
    set u_AlphaPower(value: number) {
        if (value) {
            value = Math.max(0, Math.min(8, value))
            this._shaderValues.setNumber(TransparentRimMaterial.u_AlphaPower, value)
        }
    }

    /**
     * All 强度
     */
    set u_AllPower(value: number) {
        if (value) {
            value = Math.max(0, Math.min(10, value))
            this._shaderValues.setNumber(TransparentRimMaterial.u_AllPower, value)
        }
    }

    /**
	 * 克隆。
	 * @return	 克隆副本。
	 * @override
	 */
    clone(): any {
        var dest: TransparentRimMaterial = new TransparentRimMaterial();
        this.cloneTo(dest);
        return dest;
    }
}