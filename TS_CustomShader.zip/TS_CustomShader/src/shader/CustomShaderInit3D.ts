
import Shader3D = Laya.Shader3D;
import VertexMesh = Laya.VertexMesh;
import Shader_Box from "./customMaterials/box/Shader_Box";
import UnlitGrayMaterial from "./customMaterials/unlitextend/UnlitGrayMaterial";
import TransparentRimMaterial from "./customMaterials/transparentrim/TransparentRimMaterial";

export default class CustomShaderInit3D {
    static __init__(): void {
        //unlit extend
        UnlitGrayMaterial.__Init__();
        //Transparent Rim
        TransparentRimMaterial.__Init__();
        //box
        Shader_Box.__Init__();
    }
}