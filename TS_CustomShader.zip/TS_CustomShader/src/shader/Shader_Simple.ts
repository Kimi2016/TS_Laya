import Shader3D = Laya.Shader3D;
import Vector4 = Laya.Vector4;
import BaseTexture = Laya.BaseTexture;
import BaseMaterial = Laya.BaseMaterial;
import RenderState = Laya.RenderState;

export default class Shader_Simple extends Laya.UnlitMaterial {

    static readonly NAME = "Shader_Simple";

	constructor() {
		super();
		this.setShaderName(Shader_Simple.NAME);
	}

	/**
	 * 克隆。
	 * @return	 克隆副本。
	 * @override
	 */
	clone(): any {
		var dest: Shader_Simple = new Shader_Simple();
		this.cloneTo(dest);
		return dest;
	}
}