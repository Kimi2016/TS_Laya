import { ui } from "./../ui/layaMaxUI";
import CustomShaderInit3D from "../shader/CustomShaderInit3D";
import Shader_Box from "../shader/customMaterials/box/Shader_Box";
import Shader_Simple from "../shader/Shader_Simple";
import UnlitGrayMaterial from "../shader/customMaterials/unlitextend/UnlitGrayMaterial";
import TransparentRimMaterial from "../shader/customMaterials/transparentrim/TransparentRimMaterial";
/**
 * 本示例采用非脚本的方式实现，而使用继承页面基类，实现页面逻辑。在IDE里面设置场景的Runtime属性即可和场景进行关联
 * 相比脚本方式，继承式页面类，可以直接使用页面定义的属性（通过IDE内var属性定义），比如this.tipLbll，this.scoreLbl，具有代码提示效果
 * 建议：如果是页面级的逻辑，需要频繁访问页面内多个元素，使用继承式写法，如果是独立小模块，功能单一，建议用脚本方式实现，比如子弹脚本。
 */
export default class GameUI extends ui.test.TestSceneUI {

    private mModel: Laya.Sprite3D;
    private mLayaBox: Laya.MeshSprite3D;
    private mLayaBoxTexture: Laya.Texture2D;

    constructor() {
        super();

        CustomShaderInit3D.__init__();

        //添加3D场景
        var scene: Laya.Scene3D = Laya.stage.addChild(new Laya.Scene3D()) as Laya.Scene3D;

        //添加照相机
        var camera: Laya.Camera = (scene.addChild(new Laya.Camera(0, 0.1, 100))) as Laya.Camera;
        camera.transform.translate(new Laya.Vector3(0, 3, 3));
        camera.transform.rotate(new Laya.Vector3(-30, 0, 0), true, false);
        camera.orthographic = true;
        camera.orthographicVerticalSize = 12

        //添加方向光
        var directionLight: Laya.DirectionLight = scene.addChild(new Laya.DirectionLight()) as Laya.DirectionLight;
        directionLight.color = new Laya.Vector3(0.6, 0.6, 0.6);
        directionLight.transform.worldMatrix.setForward(new Laya.Vector3(1, -1, 0));

        //添加自定义模型
        //var box: Laya.MeshSprite3D = this.mLayaBox = scene.addChild(new Laya.MeshSprite3D(Laya.PrimitiveMesh.createBox(1, 1, 1))) as Laya.MeshSprite3D;
        //box.transform.localPositionX = -1
        //box.transform.rotate(new Laya.Vector3(0, 45, 0), false, false);
        //Laya.Texture2D.load("res/layabox.png", Laya.Handler.create(this, function (tex: Laya.Texture2D) {
        //    this.mLayaBoxTexture = tex;
        //}));
        //box.meshRenderer.material = new Shader_Box();

        //添加自定义模型
        Laya.Sprite3D.load("res/model/301.lh", Laya.Handler.create(this, (sprite3D: Laya.Sprite3D) => {
            scene.addChild(sprite3D);
            this.mModel = sprite3D;
            this.mModel.transform.localPositionX = 1
            this.mModel.transform.rotate(new Laya.Vector3(0, 45, 0), false, false);
        }));

        var rotation = new Laya.Vector3(0, 0.01, 0);
        Laya.timer.frameLoop(2, this, () => {
            if (this.mModel) this.mModel.transform.rotate(rotation, false);
        })
    }

    onAwake(): void {
        this.mButton1.on(Laya.Event.CLICK, this, this.onChangeBox)
        this.mButton2.on(Laya.Event.CLICK, this, this.onChangeModel)
        this.mScrollBarR.changeHandler = new Laya.Handler(this, (v) => {
            this.onChnageScrollBar(v, 0)
        });
        this.mScrollBarG.changeHandler = new Laya.Handler(this, (v) => {
            this.onChnageScrollBar(v, 1)
        });
        this.mScrollBarB.changeHandler = new Laya.Handler(this, (v) => {
            this.onChnageScrollBar(v, 2)
        });
        this.mScrollBarA.changeHandler = new Laya.Handler(this, (v) => {
            this.onChnageScrollBar(v, 3)
        });
        this.mScrollBar.changeHandler = new Laya.Handler(this, (v) => {
            this.onChnageScrollBar(v, 4)
        });
    }

    private index = 0;

    /**
     * 更新Box材质
     */
    private onChangeBox(): void {
        console.error("开始更新Box材质");
        if (this.mLayaBox) {
            var material: any;
            if (this.index % 2 == 0) {
                material = new Laya.UnlitMaterial();
            } else {
                material = new Laya.BlinnPhongMaterial();
            }
            material.albedoTexture = this.mLayaBoxTexture;
            this.SetMaterial(this.mLayaBox.meshRenderer, material);
            this.index++;
        }
    }


    private onChnageScrollBar(value: number, type: number): void {
        console.log("滚动条的位置： value=" + value);
        if (this.mModel) {
            var skinned = this.mModel.getChildAt(0).getChildAt(0) as Laya.SkinnedMeshSprite3D;
            var material: any = skinned.skinnedMeshRenderer.material;
            if (material instanceof TransparentRimMaterial) {
                material.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
                if (type == 0) {
                    //material.albedoColorR = value
                } else if (type == 1) {
                    material.u_RimPower = value
                } else if (type == 2) {
                    material.u_InnerColorPower = value
                } else if (type == 3) {
                    material.u_AlphaPower = value
                } else if (type == 4) {
                    material.u_AllPower = value
                }
            } else if (material instanceof Laya.UnlitMaterial) {
                material.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
                if (type == 0)
                    material.albedoColorR = value
                else if (type == 1)
                    material.albedoColorG = value
                else if (type == 2)
                    material.albedoColorB = value
                else if (type == 3)
                    material.albedoColorA = value
                else if (type == 4)
                    material.albedoIntensity = value
            } else if (material instanceof Laya.BlinnPhongMaterial) {
                material.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
                if (type == 0)
                    material.albedoColorR = value
                else if (type == 1)
                    material.albedoColorG = value
                else if (type == 2)
                    material.albedoColorB = value
                else if (type == 3)
                    material.albedoColorA = value
                else if (type == 4)
                    material.albedoIntensity = value
            }
        }
    }

    /**
     * 更新模型材质
     */
    private onChangeModel(): void {
        console.error("开始更新模型材质");
        if (this.mModel) {
            var skinned: any = this.mModel.getChildAt(0).getChildAt(0) as Laya.SkinnedMeshSprite3D;
            var oldMaterial: any = skinned.skinnedMeshRenderer.material;
            var material: any;
            if (this.index % 2 == 0) {
                //material = new UnlitExtendMaterial();
                //material = new Laya.UnlitMaterial();
                //material.renderMode = Laya.UnlitMaterial.RENDERMODE_CUTOUT;
                //material.alphaTestValue = 0.5;
                material = new TransparentRimMaterial();
                material.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
            } else {
                //material = new Laya.BlinnPhongMaterial();
                material = new UnlitGrayMaterial();
            }
            material.albedoTexture = oldMaterial.albedoTexture;
            this.SetMaterial(skinned.skinnedMeshRenderer, material);
            this.index++
        }
    }

    private SetMaterial(meshRenderer: Laya.MeshRenderer, material: Laya.BaseMaterial) {
        meshRenderer.material = material
    }
}