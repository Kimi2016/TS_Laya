import { ui } from "../ui/layaMaxUI";

export default class PlayerBox1 extends ui.PlayerBoxUI {
    public mModel: Laya.Sprite3D;
    public mCamera: Laya.Camera;
    private mCViewport: Laya.Viewport;
    private mAnimator: Laya.Animator;
    private mScene3D: Laya.Scene3D;
    private mMapPos: Laya.Point;

    private mCOriginalViewportY = 0;
    private mCViewportX = 0;
    private mCViewportY = 0;
    private mCViewportWidth = 500;
    private mCViewportHeight = 400;

    constructor() {
        super();
        this.init();
    }

    private init(): void {
        var scene3D = new Laya.Scene3D();
        var camera = new Laya.Camera();
        camera.orthographic = true;
        camera.orthographicVerticalSize = 6;
        camera.clearFlag = Laya.BaseCamera.CLEARFLAG_DEPTHONLY;
        camera.transform.translate(new Laya.Vector3(0, 13, 20), false);
        camera.transform.rotate(new Laya.Vector3(-30, 0, 0), true, false);
        var cViewport = new Laya.Viewport(0, 0, this.mCViewportWidth, this.mCViewportWidth);
        camera.viewport = cViewport;

        scene3D.addChild(camera);
        this.addChild(scene3D);

        this.mMapPos = new Laya.Point(0, 0);
        this.mScene3D = scene3D;
        this.mCamera = camera;
        this.mCViewport = cViewport;
        this.Test();
    }

    private Test(): void {
        this.width = this.mCViewportWidth;
        this.height = this.mCViewportHeight;
        //在对话框中，鼠标可点击触发拖动的区域
        this.dragArea = "0,0,250,100";
        //界面拖动事件监听
        this.on(Laya.Event.DRAG_MOVE, this, this.onDragMove);
    }
    private onDragMove(): void {
        //界面中摄像机视口跟随移动
        console.log(this.mCViewportWidth, this.mCViewportHeight);
        this.mCamera.viewport = new Laya.Viewport(this.x, this.y, this.mCViewportWidth, this.mCViewportHeight);
    }

    public Update(): void {

    }

    public GetAnimator(): Laya.Animator {
        if (!this.mAnimator) {
            this.mAnimator = this.mModel.getChildAt(0).getComponent(Laya.Animator);
        }
        return this.mAnimator;
    }

    public AddModel(model: Laya.Sprite3D): void {
        this.mModel = model;
        this.mScene3D.addChild(model);
        this.mModel.transform.translate(new Laya.Vector3(0, 0, 0), false);
    }

    public SetRotate(vec3: Laya.Vector3, isLocal?: boolean, isRadian?: boolean): void {
        this.mModel.transform.rotate(vec3, isLocal, isRadian);
    }

    public SetPosOrWH(x: number, y: number, w: number, h: number): void {
        this.SetWH(w, h);
        this.SetPos(x, y);
    }

    public SetWH(w: number, h: number): void {
        //this.width = w;
        //this.height = h;
        this.mCViewportWidth = w;
        this.mCViewportHeight = h;
        this.UpdateViewport();
    }

    public SetPos(x: number, y: number): void {
        //记录所以地图位置
        this.mMapPos.setTo(x, y);
        //设置人物脚下中心点的位置
        this.x = x - this.mCViewportWidth * 0.5;
        this.y = y - this.mCViewportHeight * 0.6;
        this.UpdateViewport();
    }

    private UpdateViewport(): void {
        this.mCViewport.x = this.x;
        this.mCViewport.y = this.y;
        this.mCViewport.width = this.mCViewportWidth;
        this.mCViewport.height = this.mCViewportHeight;
        this.mCamera.viewport = this.mCViewport;
    }

    public clear(): void {
        this.mCamera = null;
        this.mCViewport = null;
        this.mAnimator = null;
    }
}