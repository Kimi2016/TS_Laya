import GameConfig from "./GameConfig";

class Main {
	constructor() {
		//根据IDE设置初始化引擎		
		if (window["Laya3D"]) Laya3D.init(GameConfig.width, GameConfig.height);
		else Laya.init(GameConfig.width, GameConfig.height, Laya["WebGL"]);
		Laya["Physics"] && Laya["Physics"].enable();
		Laya["DebugPanel"] && Laya["DebugPanel"].enable();

		this.initShader();

		Laya.stage.scaleMode = GameConfig.scaleMode;
		Laya.stage.screenMode = GameConfig.screenMode;
		Laya.stage.alignV = GameConfig.alignV;
		Laya.stage.alignH = GameConfig.alignH;
		//兼容微信不支持加载scene后缀场景
		Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;

		//打开调试面板（通过IDE设置调试模式，或者url地址增加debug=true参数，均可打开调试面板）
		if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true") Laya.enableDebugPanel();
		if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"]) Laya["PhysicsDebugDraw"].enable();
		if (GameConfig.stat) Laya.Stat.show();
		Laya.alertGlobalError = true;

		//激活资源版本控制，version.json由IDE发布功能自动生成，如果没有也不影响后续流程
		Laya.ResourceVersion.enable("version.json", Laya.Handler.create(this, this.onVersionLoaded), Laya.ResourceVersion.FILENAME_VERSION);
	}

	onVersionLoaded(): void {
		//激活大小图映射，加载小图的时候，如果发现小图在大图合集里面，则优先加载大图合集，而不是小图
		Laya.AtlasInfoManager.enable("fileconfig.json", Laya.Handler.create(this, this.onConfigLoaded));
	}

	onConfigLoaded(): void {
		//加载IDE指定的场景
		GameConfig.startScene && Laya.Scene.open(GameConfig.startScene);
	}

	//初始化我们的自定义shader
	public initShader(): void {
		//所有的attributeMap属性
		var attributeMap: Object = {
			'a_Position': Laya.VertexMesh.MESH_POSITION0,
			'a_Normal': Laya.VertexMesh.MESH_NORMAL0,
			'a_Texcoord': Laya.VertexMesh.MESH_TEXTURECOORDINATE0,
		};
		//所有的uniform属性
		var uniformMap: Object = {
			'u_MvpMatrix': Laya.Shader3D.PERIOD_SPRITE,
			'u_WorldMat': Laya.Shader3D.PERIOD_SPRITE,
			'u_texture': Laya.Shader3D.PERIOD_MATERIAL,
		};
		//注册CustomShader 
		var customShader: Laya.Shader3D = Laya.Shader3D.add("CustomShader");
		//创建一个SubShader
		var subShader: Laya.SubShader = new Laya.SubShader(attributeMap, uniformMap);
		//我们的自定义shader customShader中添加我们新创建的subShader
		customShader.addSubShader(subShader);
		//往新创建的subShader中添加shaderPass
		var vs: string = `
        #include "Lighting.glsl"; 
		attribute vec3 a_Normal;
        attribute vec2 a_Texcoord;
        attribute vec4 a_Position;
        uniform mat4 u_MvpMatrix;
        uniform mat4 u_WorldMat;
		
        varying vec2 v_Texcoord;
		varying vec3 v_Normal;
		
        void main()
        {
			gl_Position = u_MvpMatrix * a_Position;
			v_Texcoord=a_Texcoord;
			mat3 worldMat=mat3(u_WorldMat);
			v_Normal=worldMat*a_Normal;
			gl_Position=remapGLPositionZ(gl_Position); 
        }`;
		var ps: string = `
        #ifdef FSHIGHPRECISION
        precision highp float;
        #else
        precision mediump float;
		#endif
		
        #include "Lighting.glsl"; 
		varying vec2 v_Texcoord;
		uniform sampler2D u_texture;
        varying vec3 v_Normal;

		void main()
        {
			gl_FragColor=texture2D(u_texture,v_Texcoord);
			gl_FragColor=vec4(dot(gl_FragColor.rgb,vec3(0.222,0.707,0.071)));
		}`;

		/**
			gl_FragColor=vec4(v_Normal,1.0); 

			//gl_FragColor=texture2D(u_texture,v_Texcoord);
        	//gl_FragColor=dot(gl_FragColor.rgb, vec3(.222,.707,.071));
		*/
		subShader.addShaderPass(vs, ps);
	}
}
//激活启动类
new Main();
