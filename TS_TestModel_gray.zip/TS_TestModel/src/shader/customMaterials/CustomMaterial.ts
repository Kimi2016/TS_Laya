
export default class CustomMaterial extends Laya.BaseMaterial {
	public constructor() {
		super();
		this.setShaderName("CustomShader");
	}
}