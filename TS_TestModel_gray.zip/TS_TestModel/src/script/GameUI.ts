import { ui } from "./../ui/layaMaxUI";
import CustomMaterial from "../shader/customMaterials/CustomMaterial";


export default class GameUI extends ui.test.TestSceneUI {

    private mModel: Laya.Sprite3D;

    constructor() {
        super();

        //添加3D场景
        var scene: Laya.Scene3D = Laya.stage.addChild(new Laya.Scene3D()) as Laya.Scene3D;

        //添加照相机
        var camera: Laya.Camera = (scene.addChild(new Laya.Camera(0, 0.1, 100))) as Laya.Camera;
        camera.transform.translate(new Laya.Vector3(0, 7, 8));
        camera.transform.rotate(new Laya.Vector3(-30, 0, 0), true, false);

        //添加方向光
        var directionLight: Laya.DirectionLight = scene.addChild(new Laya.DirectionLight()) as Laya.DirectionLight;
        directionLight.color = new Laya.Vector3(0.6, 0.6, 0.6);
        directionLight.transform.worldMatrix.setForward(new Laya.Vector3(1, -1, 0));

        //添加自定义模型
        Laya.Sprite3D.load("res/model/301.lh", Laya.Handler.create(null, (sprite3D: Laya.Sprite3D)=> {
            scene.addChild(sprite3D);
            this.mModel = sprite3D;
            this.mModel.transform.rotate(new Laya.Vector3(0, 45, 0), false, false);
        }));
    }

    onAwake(): void {
        this.mButton.on(Laya.Event.CLICK, this, this.onButton)
    }

    private onButton(): void {
        console.error("开始置灰",this.mModel);

        if (this.mModel) {
            var material: CustomMaterial = new CustomMaterial();
            var skinned = this.mModel.getChildAt(0).getChildAt(0) as Laya.SkinnedMeshSprite3D;
            skinned.skinnedMeshRenderer.material = material;
        }
    }
}