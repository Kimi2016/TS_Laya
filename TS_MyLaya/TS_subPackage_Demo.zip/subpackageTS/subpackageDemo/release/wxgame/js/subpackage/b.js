/**
* 分包
*/
var subpackage;
(function (subpackage) {
    var b = /** @class */ (function () {
        function b() {
            //从window域里取出
            this.GameMain = window["GameMain"];
            this.ui = window["ui"];
            //监听按钮btnA的点击事件，触发后处理
            this.GameMain.newUI.btnA.on(Laya.Event.CLICK, this, this.showB);
        }
        //显示B页
        b.prototype.showB = function () {
            this.GameMain.showUI(this.ui.bUI, this.GameMain.newUI);
            //监听按钮btnB的点击事件，触发后处理
            this.GameMain.newUI.btnB.on(Laya.Event.CLICK, this, this.showA);
        };
        //显示A页
        b.prototype.showA = function () {
            this.GameMain.showUI(this.ui.aUI, this.GameMain.newUI);
            //监听按钮btnA的点击事件，触发后处理
            this.GameMain.newUI.btnA.on(Laya.Event.CLICK, this, this.showB);
        };
        return b;
    }());
    subpackage.b = b;
})(subpackage || (subpackage = {}));
new subpackage.b();
//# sourceMappingURL=b.js.map