var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var View = laya.ui.View;
var Dialog = laya.ui.Dialog;
var ui;
(function (ui) {
    var aUI = /** @class */ (function (_super) {
        __extends(aUI, _super);
        function aUI() {
            return _super.call(this) || this;
        }
        aUI.prototype.createChildren = function () {
            _super.prototype.createChildren.call(this);
            this.createView(ui.aUI.uiView);
        };
        aUI.uiView = { "type": "View", "props": { "width": 600, "height": 400 }, "child": [{ "type": "Button", "props": { "y": 189, "x": 147, "width": 296, "var": "btnA", "skin": "comp/button.png", "sizeGrid": "8,11,7,7", "labelSize": 50, "label": "跳转到B", "height": 139 } }, { "type": "Label", "props": { "y": 67, "x": 155, "text": "我是A页面", "fontSize": 60, "color": "#f3ecec" } }] };
        return aUI;
    }(View));
    ui.aUI = aUI;
})(ui || (ui = {}));
(function (ui) {
    var bUI = /** @class */ (function (_super) {
        __extends(bUI, _super);
        function bUI() {
            return _super.call(this) || this;
        }
        bUI.prototype.createChildren = function () {
            _super.prototype.createChildren.call(this);
            this.createView(ui.bUI.uiView);
        };
        bUI.uiView = { "type": "View", "props": { "width": 600, "height": 400 }, "child": [{ "type": "Button", "props": { "y": 189, "x": 147, "width": 296, "var": "btnB", "skin": "comp/button.png", "sizeGrid": "8,11,7,7", "labelSize": 50, "label": "跳转到A", "height": 139 } }, { "type": "Label", "props": { "y": 67, "x": 155, "text": "我是B页面", "fontSize": 60, "color": "#ec0f0f" } }] };
        return bUI;
    }(View));
    ui.bUI = bUI;
})(ui || (ui = {}));
console.log("ui");
//# sourceMappingURL=layaUI.max.all.js.map