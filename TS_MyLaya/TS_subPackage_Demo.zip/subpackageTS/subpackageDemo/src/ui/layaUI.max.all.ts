
import View=laya.ui.View;
import Dialog=laya.ui.Dialog;
module ui {
    export class aUI extends View {
		public btnA:Laya.Button;

        public static  uiView:any ={"type":"View","props":{"width":600,"height":400},"child":[{"type":"Button","props":{"y":189,"x":147,"width":296,"var":"btnA","skin":"comp/button.png","sizeGrid":"8,11,7,7","labelSize":50,"label":"跳转到B","height":139}},{"type":"Label","props":{"y":67,"x":155,"text":"我是A页面","fontSize":60,"color":"#f3ecec"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.aUI.uiView);

        }

    }
}

module ui {
    export class bUI extends View {
		public btnB:Laya.Button;

        public static  uiView:any ={"type":"View","props":{"width":600,"height":400},"child":[{"type":"Button","props":{"y":189,"x":147,"width":296,"var":"btnB","skin":"comp/button.png","sizeGrid":"8,11,7,7","labelSize":50,"label":"跳转到A","height":139}},{"type":"Label","props":{"y":67,"x":155,"text":"我是B页面","fontSize":60,"color":"#ec0f0f"}}]};
        constructor(){ super()}
        createChildren():void {
        
            super.createChildren();
            this.createView(ui.bUI.uiView);

        }

    }
}
console.log("ui");