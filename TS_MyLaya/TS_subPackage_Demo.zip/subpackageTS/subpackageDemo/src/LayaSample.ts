// 程序入口
class GameMain{
    private newUI:any;
    constructor()
    {
        //初始化微信小游戏
        Laya.MiniAdpter.init();

        Laya.init(0, 0, Laya.WebGL);

        Laya.stage.scaleMode = "full";
        //加载图集
        Laya.loader.load("res/atlas/comp.atlas", Laya.Handler.create(this, this.onLoaded));
    }

    //显示UI切换界面的通用函数
    private showUI(UIname:any,delUI?:any):void
    {
        if(delUI != null)
                delUI.removeSelf();//删除指定UI
        
        //实例化新的UI
        this.newUI = new UIname();
        
        //每次实例之后，更新window
        window["newUI"] = this.newUI;

        //添加UI在舞台
        Laya.stage.addChild(this.newUI);
    }

    //图集加载后回调
    private onLoaded():void
    {
        this.showUI(ui.aUI);
  
        const loadTask = wx.loadSubpackage({
                name: 'subpackage', // name 可以填 name 或者 root
                success: function(res) {
                    // 分包加载成功后通过 success 回调
                    console.log("success");
                },
                fail: function(res) {
                    // 分包加载失败通过 fail 回调
                    console.log("fail");
                }
            });       
    }

}
window["ui"] = ui;
window["GameMain"] = new GameMain();