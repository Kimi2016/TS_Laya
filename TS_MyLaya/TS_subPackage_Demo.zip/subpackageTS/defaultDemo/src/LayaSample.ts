// 程序入口
class GameMain{
    private newUI:any;
    constructor()
    {
        //初始化微信小游戏
        Laya.MiniAdpter.init();

        Laya.init(0, 0, Laya.WebGL);

        Laya.stage.scaleMode = "full";

        //加载图集
        Laya.loader.load("res/atlas/comp.atlas", Laya.Handler.create(this, this.onLoaded));

    }

    //显示UI切换界面的通用函数
    private showUI(UIname:any,delUI?:any):void
    {
        if(delUI != null)
                delUI.removeSelf();//删除指定UI
        
        //实例化新的UI
        this.newUI = new UIname();

        //添加UI在舞台
        Laya.stage.addChild(this.newUI);
    }

    //图集加载后回调
    private onLoaded():void
    {
      
        this.showUI(ui.aUI);
        //监听按钮btnA的点击事件，触发后处理
        this.newUI.btnA.on(Laya.Event.CLICK, this, this.showB);
        
    }

    //显示B页
    private showB():void
    {
        this.showUI(ui.bUI,this.newUI)

        //监听按钮btnB的点击事件，触发后处理
        this.newUI.btnB.on(Laya.Event.CLICK, this, this.showA);
    }


    //显示A页
    private showA():void
    {
        this.showUI(ui.aUI,this.newUI)
    
        //监听按钮btnA的点击事件，触发后处理
        this.newUI.btnA.on(Laya.Event.CLICK, this, this.showB);
    }
}
new GameMain();