import { ui } from "../ui/layaMaxUI";
import GameConfig from "../GameConfig";

export default class RolePropUI extends ui.RolePropUIUI {
    /*界面中的3D场景*/
    private scene3D: Laya.Scene3D;
    /*界面中的摄像机*/
    public camera: Laya.Camera;
    /*界面中的3D角色*/
    private role: Laya.Sprite3D;
    /*界面中在舞台水平居中位置*/
    private xx: number = 0;
    /*界面中在舞台垂直居中位置*/
    private yy: number = 0;

    constructor() {
        super();
    }

    onEnable(): void {
    }

    onDisable(): void {
    }

    onAwake(): void {

        //设置UI位置为居中显示
        this.xx = (GameConfig.width - this.width) / 2;
        this.yy = (GameConfig.height - this.height) / 2;
        this.pos(this.xx, this.yy);

        //与UI搭配的3D场景
        this.scene3D = new Laya.Scene3D();
        this.addChild(this.scene3D);
        //在对话框中，鼠标可点击触发拖动的区域
        this.dragArea = "0,0,200,80";

        //创建摄像机
        this.camera = new Laya.Camera();
        //清除标记，仅深度
        this.camera.clearFlag = Laya.BaseCamera.CLEARFLAG_DEPTHONLY;
        this.scene3D.addChild(this.camera);
        //设置摄像机视口大小与UI一致
        this.camera.viewport = new Laya.Viewport(this.xx, this.yy, this.width, this.height);
        //摄像机位置
        this.camera.transform.translate(new Laya.Vector3(0, 1.2, 3), false);
        //关闭按钮事件监听
        this.btn_close.on(Laya.Event.MOUSE_DOWN, this, this.onClose);

        Laya.Sprite3D.load("res/animation/player/mage/mage.lh", Laya.Handler.create(this, this.onLoadCompleted));

        //界面拖动事件监听
        this.on(Laya.Event.DRAG_MOVE,this,this.onDragMove);
    }

    onLoadCompleted(sprite3D: Laya.Sprite3D): void {
        var role = sprite3D.clone() as Laya.Sprite3D;
        //添加角色
        this.scene3D.addChild(role);
        //修改角色位置
        role.transform.translate(new Laya.Vector3(0, 0, 0), false);
    }

    /*界面拖动回调*/
    private onDragMove(): void {
        //界面中摄像机视口跟随移动
        this.camera.viewport = new Laya.Viewport(this.x, this.y, this.width, this.height);
    }

    /*关闭按钮事件回调*/
    private onClose(): void {
        //移除UI界面
        Laya.stage.removeChild(this);
        //恢复UI位置为居中显示
        this.pos(this.xx, this.yy);
        //恢复摄像机视口大小与位置
        this.camera.viewport = new Laya.Viewport(this.xx, this.yy, this.width, this.height);
    }
}